<?php

return [
    'module_name' => [
        'news_cat' => 'دسته بندی خبر',
        'news' => 'خبر',
        'content' => 'محتوی',
    ],

];
