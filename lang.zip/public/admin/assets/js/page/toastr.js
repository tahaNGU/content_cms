"use strict";

$("#toastr-1").click(function () {
  iziToast.info({
    title: 'سلام دنیا!',
    message: 'لورم به سادگی متن ساختگی صنعت چاپ و تحریر است. ',
    position: 'topRight'
  });
});

$("#toastr-2").click(function () {
  iziToast.success({
    title: 'سلام دنیا!',
    message: 'لورم به سادگی متن ساختگی صنعت چاپ و تحریر است. ',
    position: 'topRight'
  });
});

$("#toastr-3").click(function () {
  iziToast.warning({
    title: 'سلام دنیا!',
    message: 'لورم به سادگی متن ساختگی صنعت چاپ و تحریر است. ',
    position: 'topRight'
  });
});

$("#toastr-4").click(function () {
  iziToast.error({
    title: 'سلام دنیا!',
    message: 'لورم به سادگی متن ساختگی صنعت چاپ و تحریر است. ',
    position: 'topRight'
  });
});

$("#toastr-5").click(function () {
  iziToast.show({
    title: 'سلام دنیا!',
    message: 'لورم به سادگی متن ساختگی صنعت چاپ و تحریر است. ',
    position: 'bottomRight'
  });
});

$("#toastr-6").click(function () {
  iziToast.show({
    title: 'سلام دنیا!',
    message: 'لورم به سادگی متن ساختگی صنعت چاپ و تحریر است. ',
    position: 'bottomCenter'
  });
});

$("#toastr-7").click(function () {
  iziToast.show({
    title: 'سلام دنیا!',
    message: 'لورم به سادگی متن ساختگی صنعت چاپ و تحریر است. ',
    position: 'bottomLeft'
  });
});

$("#toastr-8").click(function () {
  iziToast.show({
    title: 'سلام دنیا!',
    message: 'لورم به سادگی متن ساختگی صنعت چاپ و تحریر است. ',
    position: 'topCenter'
  });
});
