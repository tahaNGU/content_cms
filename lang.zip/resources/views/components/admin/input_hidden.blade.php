@props(['name'=>'id','value'=>''])
<input type="hidden" name="{{$name}}" value="{{$value}}">
