<!-- General JS Scripts -->
<script src="{{asset("admin/assets/js/app.min.js")}}"></script>
<script src="{{asset("admin/assets/boundles/summernote/summernote-bs4.js")}}"></script>
<script src="{{asset("admin/assets/js/tagsinput.js")}}"></script>
<script src="{{asset("admin/assets/boundles/select2/dist/js/select2.full.min.js")}}"></script>
<script src="{{asset("admin/assets/js/page/sweetalert.js")}}"></script>

<script src="{{asset("admin/assets/js/scripts.js")}}"></script>
<script src="{{asset("admin/assets/js/custom.js")}}"></script>
